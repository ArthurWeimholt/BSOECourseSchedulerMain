"""
This file defines the database models
"""
# """
# This file defines the database models
# """



import datetime
from .common import db, Field, auth
from pydal.validators import *
import datetime
from .common import db, Field, auth
from pydal.validators import *


def get_user_email():
    return auth.current_user.get('email') if auth.current_user else None

def get_contact_id():
    return auth.current_user.get('email') if auth.current_user else None

def get_time():
    return datetime.datetime.utcnow()

def get_user():
    return auth.current_user.get('id') if auth.current_user else None


### Define your table below
#
# db.define_table('thing', Field('name'))
#
## always commit your models to avoid problems later

#db.define_table(
    #'contact',
   # Field('first_name', requires=IS_NOT_EMPTY()),
   # Field('last_name', requires=IS_NOT_EMPTY()),
   # Field('user_email', default=get_user_email),
#)

#db.contact.id.readable = db.contact.id.writable = False
#db.contact.user_email.readable = db.contact.user_email.writable = False

#db.define_table(
    #'number',
    #Field('number', requires=IS_NOT_EMPTY()),
    #Field('contact_id', 'reference contact'),
   # Field('type', requires=IS_NOT_EMPTY()),
    # Field('user_email', default=get_user_email)
#)

# New

db.define_table(
    'major',
    Field('name', requires=IS_NOT_EMPTY()),
    Field('requirement_name', requires=IS_NOT_EMPTY()),
)

db.define_table(
    'student',
    Field('student_id', 'reference auth_user', default=get_user),
    Field('major_id', 'reference major'),
)

db.define_table(
    'course',
    Field('name', requires=IS_NOT_EMPTY()), # CSE12
    Field('description'),
    Field('offered_fall', 'boolean'),
    Field('offered_winter', 'boolean'),
    Field('offered_spring', 'boolean'),
    Field('offered_summer', 'boolean'),
    Field('requirement_name', default=None),
)



db.define_table(
    'studentCourse',
    Field('student_id', 'reference auth_user', default=get_user),
    Field('course_id', 'reference course'),
    Field('season'),  # Fall , Winter, Spring, Summer.
    Field('year'),  # Freshman, Sophomore, Junior, Senior, Extra
    Field('period', 'integer')  # 0-4
)

#db.define_table(
   # 'scheduleRow',
   # Field('student_id', 'reference auth_user', default=get_user),
   # Field('depth', 'integer'),
  #  Field('fall'),
  #  Field('winter'),
  #  Field('spring'),
 #   Field('summer'),
#)

db.define_table(
    'requirement',
    Field('requirement_name'),
    Field('type'),  # AND, OR, SINGLE
    Field('course_requirement_name'),  # conditional
    Field('course_or_requirement', 'boolean'),  # course requirement boolean true=course false=requirement
)

db.major.truncate()
db.major.insert(name="Computer Science B.S.", requirement_name = "REQComputerScienceB.S.")

db.course.truncate()
db.course.insert(name= "CSE 20", description="Beginning Programming in Python", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=False)
db.course.insert(name= "CSE 30", description="Programming Abstractions: Python", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=False, requirement_name="REQCSE30")
db.course.insert(name= "CSE 16", description="Applied Discrete Mathematics", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQCSE16")
db.course.insert(name= "CSE 12", description="Computer Systems and Assembly Language and Lab", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQCSE12")
db.course.insert(name= "MATH 19A", description="Calculus for Science, Engineering, and Mathematics", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQMATH19A")
db.course.insert(name= "MATH 19B", description="Calculus for Science, Engineering, and Mathematics", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQMATH19B")
db.course.insert(name= "MATH 20A", description="Honors Calculus", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQMATH20A")
db.course.insert(name= "MATH 20B", description="Honors Calculus", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQMATH20B")
db.course.insert(name= "CSE 13S", description="Computer Systems and C Programming", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=False, requirement_name="REQCSE13S")
db.course.insert(name= "AM 10", description="Mathematical Methods for Engineers I", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=False, requirement_name="REQAM10")
db.course.insert(name= "MATH 21", description="Linear Algebra", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQMATH21")
db.course.insert(name= "AM 30", description="Multivariable Calculus for Engineers", offered_fall = True, offered_winter = False, offered_spring = True, offered_summer=False, requirement_name="REQAM30")
db.course.insert(name= "MATH 23A", description="Vector Calculus", offered_fall = True, offered_winter = True, offered_spring = True, offered_summer=True, requirement_name="REQMATH23A")
db.course.insert(name= "ECE 30", description="Engineering Principles of Electronics", offered_fall = False, offered_winter = False, offered_spring = True, offered_summer=False, requirement_name="REQECE30")


db.requirement.truncate()
db.requirement.insert(requirement_name="REQCSE30", type="SINGLE", course_requirement_name="CSE 20", course_or_requirement="True")
db.requirement.insert(requirement_name="REQCSE16", type ="OR", course_requirement_name="MATH 19A", course_or_requirement = "True")
db.requirement.insert(requirement_name="REQCSE16", type ="OR", course_requirement_name="MATH 19B", course_or_requirement = "True")
db.requirement.insert(requirement_name="REQCSE16", type ="OR", course_requirement_name="MATH 20A", course_or_requirement = "True")
db.requirement.insert(requirement_name="REQCSE16", type ="OR", course_requirement_name="MATH 20B", course_or_requirement = "True")



#db.studentCourse.truncate()
#db.studentCourse.insert(student_id= "1", course_id="1", season="Fall", year="Freshman", period=0)
#db.studentCourse.insert(student_id= "1", course_id="3", season="Winter", year="Freshman", period=1)




#db.number.id.readable = False
#db.number.contact_id.readable = db.number.contact_id.writable = False

db.commit()
